package com.piazza2.chat.model;

public enum MessageType {
    CHAT,
    CONNECT,
    DISCONNECT
}
