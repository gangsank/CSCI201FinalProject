package com.angadsChatPiazza2.spring.ws.api.model;

public class Notification {
    private String content;
    private String sender;
    private NotificationType type;

    public enum NotificationType {
        Notification
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public NotificationType getType() {
        return type;
    }

    public void setType(NotificationType type) {
        this.type = type;
    }

}

