package com.angadsChatPiazza2.spring.ws.api.controller;

import com.angadsChatPiazza2.spring.ws.api.model.ChatMessage;
import com.angadsChatPiazza2.spring.ws.api.model.Notification;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {

	@MessageMapping("/chat.register")
	@SendTo("/topic/public")
	public ChatMessage register(@Payload ChatMessage chatMessage, SimpMessageHeaderAccessor headerAccessor) {
		headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
		System.out.println("Bing bang boong new user added '"+chatMessage.getSender()+"'");
		return chatMessage;
	}

	@MessageMapping("/chat.send")
	@SendTo("/topic/public")
	public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
		System.out.println("New message from: "+"'"+chatMessage.getSender()+"'" +" | Content: "+"'"+chatMessage.getContent()+"'");
		return chatMessage;
	}

	@MessageMapping("/notification.send")
	@SendTo("/topic/public")
	public Notification sendNotification(@Payload Notification notif) {
		System.out.println("New notification from: "+"'"+notif.getSender()+"'" +" | Content: "+"'"+notif.getContent()+"'");
		return notif;
	}

}
